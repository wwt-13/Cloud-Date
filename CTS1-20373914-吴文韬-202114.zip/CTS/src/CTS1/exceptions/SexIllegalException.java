package CTS1.exceptions;

public class SexIllegalException extends BaseException{
    public SexIllegalException(String message) {
        super(message);
    }
}

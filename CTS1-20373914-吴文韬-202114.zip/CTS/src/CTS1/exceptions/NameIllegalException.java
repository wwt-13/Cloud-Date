package CTS1.exceptions;

public class NameIllegalException extends BaseException{
    public NameIllegalException(String message) {
        super(message);
    }
}

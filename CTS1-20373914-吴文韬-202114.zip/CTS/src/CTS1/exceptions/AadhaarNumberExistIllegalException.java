package CTS1.exceptions;

public class AadhaarNumberExistIllegalException extends BaseException{
    public AadhaarNumberExistIllegalException(String message) {
        super(message);
    }
}

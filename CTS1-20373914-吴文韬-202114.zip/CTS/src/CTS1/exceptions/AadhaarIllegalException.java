package CTS1.exceptions;

public class AadhaarIllegalException extends BaseException{
    public AadhaarIllegalException(String message) {
        super(message);
    }
}

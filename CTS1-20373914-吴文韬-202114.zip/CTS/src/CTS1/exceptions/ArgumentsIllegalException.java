package CTS1.exceptions;

public class ArgumentsIllegalException extends BaseException{
    public ArgumentsIllegalException(String message) {
        super(message);
    }
}
